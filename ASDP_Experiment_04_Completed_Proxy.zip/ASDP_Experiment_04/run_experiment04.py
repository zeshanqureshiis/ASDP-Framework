"""ASDP Experiment 04: reproducible proxy Random Forest comparison and explainability.
Usage: python run_experiment04.py '/path/to/HESD(2).zip' --out results
Requires pandas numpy scipy scikit-learn joblib. Optional: shap.
This is NOT recovery of the original ASDP RF model.
"""
import argparse, zipfile, io, json, time, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.decomposition import TruncatedSVD
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix
from sklearn.inspection import permutation_importance
from sklearn.model_selection import ParameterGrid
import joblib

p=argparse.ArgumentParser();p.add_argument('dataset_zip');p.add_argument('--out',default='results');p.add_argument('--train-max',type=int,default=80000);p.add_argument('--seed',type=int,default=47);p.add_argument('--svd',type=int,default=128);p.add_argument('--test-explain',type=int,default=500);args=p.parse_args()
out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(args.dataset_zip) as z:
    data=z.read('HESD/data/HESD.csv')
sha=hashlib.sha256(data).hexdigest()
df=pd.read_csv(io.BytesIO(data),low_memory=False)
assert df[['conversation_id','turn_id']].duplicated().sum()==0
assert not (set(df.loc[df.split=='train','conversation_id']) & set(df.loc[df.split=='test','conversation_id']))
assert not (set(df.loc[df.split=='train','scenario_family']) & set(df.loc[df.split=='test','scenario_family']))
df=df.sort_values(['conversation_id','turn_id']).reset_index(drop=True)
for k in (1,2):df[f'prev{k}']=df.groupby('conversation_id').interaction_text.shift(k).fillna('')
df['history_text']=df.prev2.astype(str)+' '+df.prev1.astype(str)+' '+df.interaction_text.astype(str)
train=df[df.split=='train'].sample(n=min(args.train_max,(df.split=='train').sum()),random_state=args.seed).sort_index()
val=df[df.split=='validation'];test=df[df.split=='test']
assert len(val)>0 and len(test)>0
textvec=TfidfVectorizer(ngram_range=(1,2),min_df=3,max_features=30000,sublinear_tf=True,dtype=np.float32)
trt=textvec.fit_transform(train.history_text);vat=textvec.transform(val.history_text);tet=textvec.transform(test.history_text)
svd=TruncatedSVD(n_components=args.svd,random_state=args.seed)
tr_dense=svd.fit_transform(trt);va_dense=svd.transform(vat);te_dense=svd.transform(tet)
meta=['enterprise_domain','user_role','asset_category']
enc=OneHotEncoder(handle_unknown='ignore',sparse_output=False,dtype=np.float32)
trm=enc.fit_transform(train[meta].fillna(''));vam=enc.transform(val[meta].fillna(''));tem=enc.transform(test[meta].fillna(''))
Xtr=np.hstack([tr_dense,trm]).astype(np.float32);Xva=np.hstack([va_dense,vam]).astype(np.float32);Xte=np.hstack([te_dense,tem]).astype(np.float32)
features=[f'text_svd_{i:03}' for i in range(args.svd)]+list(enc.get_feature_names_out(meta))
ytr=train.security_class.to_numpy();yva=val.security_class.to_numpy();yte=test.security_class.to_numpy()
# All tuning uses validation; test is evaluated exactly once per final selected model.
rf_grid=list(ParameterGrid({'n_estimators':[150,300],'max_depth':[None,24],'min_samples_leaf':[1,3],'max_features':['sqrt']}))
rows=[];best=None;best_score=-1
for j,params in enumerate(rf_grid):
    start=time.perf_counter();model=RandomForestClassifier(**params,n_jobs=-1,random_state=args.seed,class_weight='balanced_subsample')
    model.fit(Xtr,ytr);pred=model.predict(Xva);score=f1_score(yva,pred,average='macro',zero_division=0)
    rows.append({'model':'RandomForest','trial':j,'validation_macro_f1':score,'fit_seconds':time.perf_counter()-start,**params})
    if score>best_score:best_score=score;best=model;best_params=params
pd.DataFrame(rows).to_csv(out/'rf_validation_tuning.csv',index=False)
# Keep training sample identical across comparison models.
models={'RandomForest':best,'LogisticRegression':LogisticRegression(max_iter=1500,class_weight='balanced',random_state=args.seed), 'HistGradientBoosting':HistGradientBoostingClassifier(max_iter=150,random_state=args.seed)}
results=[];pred_table=test[['conversation_id','turn_id','security_class']].copy()
for name,model in models.items():
    if name!='RandomForest':model.fit(Xtr,ytr)
    pred=model.predict(Xte);pred_table[name]=pred
    results.append({'model':name,'test_accuracy':accuracy_score(yte,pred),'test_macro_f1':f1_score(yte,pred,average='macro',zero_division=0),'validation_macro_f1':f1_score(yva,model.predict(Xva),average='macro',zero_division=0)})
    pd.DataFrame(confusion_matrix(yte,pred,labels=sorted(np.unique(yte))),index=sorted(np.unique(yte)),columns=sorted(np.unique(yte))).to_csv(out/f'confusion_{name}.csv')
    (out/f'report_{name}.json').write_text(json.dumps(classification_report(yte,pred,output_dict=True,zero_division=0),indent=2))
pd.DataFrame(results).to_csv(out/'test_metrics.csv',index=False);pred_table.to_csv(out/'paired_test_predictions.csv',index=False)
# Explainability: impurity importance + permutation importance on a fixed stratified test sample.
imp=pd.DataFrame({'feature':features,'rf_impurity_importance':best.feature_importances_}).sort_values('rf_impurity_importance',ascending=False)
imp.to_csv(out/'rf_impurity_importance.csv',index=False)
idx=(test.groupby('security_class',group_keys=False).apply(lambda x:x.sample(n=min(len(x),max(1,args.test_explain//test.security_class.nunique())),random_state=args.seed),include_groups=False).index)
pos=test.index.get_indexer(idx)
perm=permutation_importance(best,Xte[pos],yte[pos],scoring='f1_macro',n_repeats=5,random_state=args.seed,n_jobs=1)
pd.DataFrame({'feature':features,'permutation_mean':perm.importances_mean,'permutation_std':perm.importances_std}).sort_values('permutation_mean',ascending=False).to_csv(out/'rf_permutation_importance.csv',index=False)
joblib.dump({'rf':best,'svd':svd,'tfidf':textvec,'metadata_encoder':enc,'features':features,'rf_params':best_params},out/'model_bundle.joblib')
manifest={'experiment':'04 Random Forest evaluation and explainability proxy','dataset_sha256':sha,'seed':args.seed,'train_turns':len(train),'validation_turns':len(val),'test_turns':len(test),'train_max':args.train_max,'features':'current plus two prior texts via TF-IDF/SVD and observable enterprise metadata','excluded':'all target-derived and post-outcome fields','random_forest_parameters':best_params,'limitations':['new proxy model, not historical ASDP RF','synthetic HESD','SVD components are latent, not individually human-readable','impurity importance is not causal explanation','no live ASDP intervention']}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(pd.DataFrame(results).to_string(index=False));print('Saved to',out)
