import os,io,zipfile,json,time
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['OMP_NUM_THREADS']='2'
import pandas as pd,numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import f1_score
from pathlib import Path
p=Path('/mnt/data/ASDP_Experiment_04/results'); t=time.time()
with zipfile.ZipFile('/mnt/data/HESD(2).zip') as z: df=pd.read_csv(io.BytesIO(z.read('HESD/data/HESD.csv')),low_memory=False)
df=df.sort_values(['conversation_id','turn_id']).reset_index(drop=True)
for k in (1,2):df[f'prev{k}']=df.groupby('conversation_id').interaction_text.shift(k).fillna('')
df['history_text']=df.prev2.astype(str)+' '+df.prev1.astype(str)+' '+df.interaction_text.astype(str)
tr=df[df.split=='train'].sample(n=10000,random_state=47).sort_index();te=df[df.split=='test']
v=TfidfVectorizer(ngram_range=(1,2),min_df=3,max_features=30000,sublinear_tf=True,dtype=np.float32)
trt=v.fit_transform(tr.history_text);tet=v.transform(te.history_text)
s=TruncatedSVD(n_components=24,random_state=47);a=s.fit_transform(trt);b=s.transform(tet)
meta=['enterprise_domain','user_role','asset_category'];e=OneHotEncoder(handle_unknown='ignore',sparse_output=False,dtype=np.float32)
X=np.hstack([a,e.fit_transform(tr[meta].fillna(''))]).astype('float32');Y=np.hstack([b,e.transform(te[meta].fillna(''))]).astype('float32')
f=['text_svd_%03d'%i for i in range(24)]+list(e.get_feature_names_out(meta))
rf=RandomForestClassifier(n_estimators=300,max_depth=24,min_samples_leaf=3,max_features='sqrt',class_weight='balanced_subsample',random_state=47,n_jobs=2)
rf.fit(X,tr.security_class); pred=rf.predict(Y)
old=pd.read_csv(p/'paired_test_predictions.csv'); aligned=te[['conversation_id','turn_id']].reset_index(drop=True).equals(old[['conversation_id','turn_id']].reset_index(drop=True))
match=float(np.mean(pred==old.RandomForest.to_numpy())) if aligned else None
print('fit complete',round(time.time()-t,1),'matched',match,flush=True)
if match is None or match<0.99: raise RuntimeError('Model reproduction mismatch; explainability cannot be attached to original results')
# Held-out stratified sample; permutation importance measured by macro F1.
idx=np.concatenate([np.random.default_rng(47+i).choice(np.flatnonzero(te.security_class.to_numpy()==c),size=min(15,int((te.security_class==c).sum())),replace=False) for i,c in enumerate(sorted(te.security_class.unique()))])
perm=permutation_importance(rf,Y[idx],te.security_class.to_numpy()[idx],scoring='f1_macro',n_repeats=3,random_state=47,n_jobs=1)
pd.DataFrame({'feature':f,'permutation_mean':perm.importances_mean,'permutation_std':perm.importances_std}).sort_values('permutation_mean',ascending=False).to_csv(p/'rf_permutation_importance.csv',index=False)
print('permutation complete',round(time.time()-t,1),flush=True)
try:
 import shap
 ex=shap.TreeExplainer(rf)
 # keep exact RF; 20 test samples, five classes; SHAP runtime may be significant.
 sv=ex.shap_values(Y[idx[:20]],check_additivity=False)
 if isinstance(sv,list): values=np.stack(sv,axis=-1)
 else: values=np.asarray(sv)
 if values.ndim==3: means=np.abs(values).mean(axis=(0,2))
 else: means=np.abs(values).mean(axis=0)
 pd.DataFrame({'feature':f,'mean_abs_shap':means}).sort_values('mean_abs_shap',ascending=False).to_csv(p/'rf_shap_global.csv',index=False)
 (p/'shap_metadata.json').write_text(json.dumps({'n_explained':20,'background':'TreeExplainer tree path dependent default','method':'mean absolute SHAP across explained turns and classes','historical_prediction_agreement':match},indent=2))
 print('SHAP complete',round(time.time()-t,1),flush=True)
except Exception as exc:
 (p/'shap_error.txt').write_text(repr(exc));print('SHAP failed',repr(exc),flush=True)
(p/'reproduction.json').write_text(json.dumps({'test_predictions_exact_match_fraction':match,'sample_size_per_class_permutation':15,'permutation_repeats':3,'train_sample':10000,'svd_components':24,'runtime_seconds':round(time.time()-t,2)},indent=2))
