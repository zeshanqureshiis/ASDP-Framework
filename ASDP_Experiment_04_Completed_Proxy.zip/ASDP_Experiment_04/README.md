# Experiment 04 — Random Forest evaluation and explainability

This is a **new, leakage-controlled HESD proxy experiment**, not a recovered run of the historical ASDP Random Forest classifier. It uses the frozen conversation- and scenario-family-disjoint partitions and the same 80,000-turn training sample seed as Experiments 01–03. The input is current text plus two preceding turns and observable enterprise metadata; label-derived fields are excluded.

Run: `pip install pandas numpy scipy scikit-learn joblib` then `python run_experiment04.py '/path/to/HESD(2).zip' --out results`.

The script tunes Random Forest on validation data, evaluates Random Forest, logistic regression, and histogram gradient boosting on the same frozen test set, saves paired predictions and confusion matrices, and computes Random Forest impurity and permutation importance. It does not claim SHAP explanations or original-model reconstruction. No results are pre-filled; execution is required. This is a first-pass protocol and should be inspected for compute capacity and version compatibility before journal submission.
