# Experiment 04 — Random Forest Evaluation and Explainability

## Scope and provenance
This is a newly trained, leakage-controlled **HESD proxy classification experiment**, not recovery of the historical ASDP Random Forest or a full ASDP intervention evaluation. Source: HESD(2).zip; SHA-256 of CSV: 8d9dafd575118087fa3b56972a9336d1e3ae8dff134ba7dd70edadbfff1c5cdd. Seed 47. The held-out test has 19,991 turns; training uses 10,000 sampled turns and validation 19,873 turns. Input: current and two preceding turns, TF–IDF transformed to 24 SVD dimensions, plus one-hot observable domain/role/asset metadata. Label-derived fields excluded. Training/test scenario families and conversations are disjoint.

## Model comparison (same test turns)

| model                |   test_accuracy |   test_macro_f1 |   validation_macro_f1 |
|:---------------------|----------------:|----------------:|----------------------:|
| RandomForest         |          0.9035 |          0.8106 |                0.7986 |
| LogisticRegression   |          0.7775 |          0.6576 |                0.6441 |
| HistGradientBoosting |          0.9119 |          0.8629 |                0.8600 |

Conversation-cluster bootstrap (200 replicates): RF Macro-F1 95% interval [0.7994, 0.8218]; histogram gradient boosting [0.8546, 0.8710]. HGB minus RF Macro-F1 interval [0.0434, 0.0634]. **RF does not outperform HGB** in this proxy benchmark. Logistic regression is a linear baseline; no deep learning baseline has been run.

## Random Forest tuning

Validation Macro-F1 was used to select among the recorded 4 configurations. Best: 300 trees, maximum depth 24, minimum leaf size 3, sqrt feature sampling, balanced_subsample class weighting, random_state 47. Full tuning trial table: `rf_validation_tuning.csv`.

## Explainability

The original run's RF impurity importance is in `rf_impurity_importance.csv`. Because the original fitted model was not saved, we independently retrained an RF using the documented preprocessing and parameters. Its held-out predictions agree with the archived RF predictions on **99.555%** of turns, not 100%; minor preprocessing numerical differences may affect individual predictions. **Permutation and SHAP outputs apply to this independently retrained proxy model, not to the original archived RF model or historical ASDP model.**

Permutation importance uses a stratified 75-turn held-out subset (15 per class), 3 repeats, macro-F1 scoring. TreeSHAP uses 20 held-out turns and reports mean absolute values across classes. These samples are small and explanations are exploratory. SVD dimensions are latent features; neither impurity nor SHAP values directly explain semantic concepts or establish causality. No LIME analysis was performed.

### Top original-run RF impurity features

| feature      |   rf_impurity_importance |
|:-------------|-------------------------:|
| text_svd_001 |                  0.18232 |
| text_svd_003 |                  0.12319 |
| text_svd_000 |                  0.07058 |
| text_svd_002 |                  0.06019 |
| text_svd_004 |                  0.05356 |
| text_svd_021 |                  0.04689 |
| text_svd_019 |                  0.04177 |
| text_svd_005 |                  0.03599 |
| text_svd_010 |                  0.03409 |
| text_svd_015 |                  0.03272 |

### Top retrained RF permutation features

| feature      |   permutation_mean |   permutation_std |
|:-------------|-------------------:|------------------:|
| text_svd_001 |            0.27077 |           0.05156 |
| text_svd_003 |            0.23509 |           0.05379 |
| text_svd_000 |            0.08968 |           0.02038 |
| text_svd_019 |            0.03646 |           0.00897 |
| text_svd_009 |            0.03609 |           0.00117 |
| text_svd_021 |            0.03567 |           0.01331 |
| text_svd_002 |            0.03495 |           0.02035 |
| text_svd_023 |            0.02883 |           0.01494 |
| text_svd_022 |            0.02337 |           0.00898 |
| text_svd_007 |            0.02177 |           0.01578 |

### Top retrained RF SHAP features

| feature      |   mean_abs_shap |
|:-------------|----------------:|
| text_svd_001 |         0.09333 |
| text_svd_003 |         0.03971 |
| text_svd_000 |         0.03036 |
| text_svd_002 |         0.02320 |
| text_svd_004 |         0.01888 |
| text_svd_021 |         0.01577 |
| text_svd_019 |         0.01434 |
| text_svd_022 |         0.01219 |
| text_svd_010 |         0.01059 |
| text_svd_005 |         0.01017 |

## Limitations

- Small 10,000-turn training sample instead of originally planned 80,000 turns; 24 rather than 128 SVD components due compute limits.
- No deep learning baseline; HGB and logistic regression are the two available alternatives.
- The archived RF model was not persisted; new permutation and SHAP estimates use an approximately reproduced RF.
- Synthetic dataset and proxy task do not validate end-to-end ASDP actions or deployment performance.
- Report measured evidence without claiming Random Forest superiority or full SHAP/LIME analysis of historical ASDP.

## Figure files

`model_comparison.png`, `rf_impurity_importance.png`, `rf_permutation_importance.png`, `rf_shap_importance.png`.
