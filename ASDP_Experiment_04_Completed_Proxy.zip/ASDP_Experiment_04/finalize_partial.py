import pandas as pd,numpy as np,json,hashlib,zipfile
from pathlib import Path
from sklearn.metrics import f1_score
p=Path('/mnt/data/ASDP_Experiment_04/results'); d=pd.read_csv(p/'paired_test_predictions.csv'); names=['RandomForest','LogisticRegression','HistGradientBoosting']; rng=np.random.default_rng(47)
groups=d.groupby('conversation_id').indices; keys=list(groups); vals=list(groups.values()); rows=[]
for i in range(200):
 ids=rng.integers(0,len(keys),len(keys)); ix=np.concatenate([vals[j] for j in ids]); yy=d.security_class.to_numpy()[ix]
 r={'bootstrap_iteration':i}
 for name in names:r[name]=f1_score(yy,d[name].to_numpy()[ix],average='macro',zero_division=0)
 r['HGB_minus_RF']=r['HistGradientBoosting']-r['RandomForest'];rows.append(r)
b=pd.DataFrame(rows);b.to_csv(p/'conversation_cluster_bootstrap.csv',index=False)
summary={c:{'ci_95_low':float(b[c].quantile(.025)),'ci_95_high':float(b[c].quantile(.975))} for c in names+['HGB_minus_RF']}
(p/'bootstrap_summary.json').write_text(json.dumps(summary,indent=2))
with zipfile.ZipFile('/mnt/data/HESD(2).zip') as z: sha=hashlib.sha256(z.read('HESD/data/HESD.csv')).hexdigest()
manifest={'status':'partial: model comparisons complete; permutation importance and SHAP not completed','dataset_sha256':sha,'train_sample':10000,'validation_records':19873,'test_records':19991,'seed':47,'svd_components':24,'random_forest_best_params':{'n_estimators':300,'max_depth':24,'min_samples_leaf':3,'max_features':'sqrt'},'note':'New HESD proxy models, not original ASDP Random Forest. Training sample smaller than planned 80000 due compute constraints. Impurity importance available but not semantic-level explanations.'}
(p/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(summary,indent=2))
