# Chapter 6 Results Starter — ASDP v1.2

ASDP v1.2 adds a calibrated supervised decision layer using the ASDP feature vector.

## ASDP v1.2 Calibrated Results
- Accuracy: 0.788
- Macro Precision: 0.858
- Macro Recall: 0.782
- Macro F1: 0.806
- Semantic Leakage Detection Rate: 0.863
- False Intervention Rate: 0.000
- Legitimate Conversation Preservation: 1.000
- Trust Stability Index: 0.956
- Risk Stability Index: 0.908
- Knowledge Exposure Reduction: 0.813

## Best Non-ASDP Baseline
Best baseline by Macro F1: Prompt_Filtering
- Macro F1: 0.447
- SLDR: 0.596
- LCP: 1.000

## Runtime
- Interactions processed: 2105
- Runtime: 11.404 seconds
- Latency: 5.418 ms/interaction
- Throughput: 184.58 interactions/second
