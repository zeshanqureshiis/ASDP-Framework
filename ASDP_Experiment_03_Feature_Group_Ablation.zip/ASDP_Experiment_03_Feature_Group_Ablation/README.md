# Experiment 03 — Observable feature-group ablation

## Run
`python run.py /path/to/HESD(1).zip`

Requires Python with pandas, numpy, scipy, scikit-learn. Input is the user-provided updated HESD archive; the full dataset is not duplicated here.

The training set is a fixed 80,000-turn sample from the frozen train partition, random seed 47. The entire frozen test partition is evaluated. No test fitting. Text is TF-IDF with unigrams/bigrams and a balanced SGD logistic-loss classifier. Metadata is one-hot encoded using training categories. Three feature groups are compared with common training/test samples. Bootstrap resamples whole test conversations (300 replicates).

## Interpretation
This is a leakage-controlled **proxy feature-group ablation**, not a causal ablation of ASDP modules ATS, EKS, CIW, KEI, DRS or SSS. The new results must not be interpreted as operational decoy interception or independently verified enterprise deployment. The confidence interval for the metadata addition crosses zero.

## Files
`run.py`: executable pipeline; `metrics.csv`: accuracy, Macro-F1, Reconstruction F1, hard-negative false-alarm rate; `paired_predictions.csv`: paired test predictions; `cluster_bootstrap.csv`: conversation-level bootstrap; `confusion_*.csv`: confusion matrices; `reconstruction_top_features.csv`: model coefficients, not causal SHAP values; `manifest.json`: provenance and reproducibility details.
