import io,zipfile,hashlib,json,sys,platform
from pathlib import Path
import numpy as np,pandas as pd,scipy,sklearn
from scipy.sparse import hstack
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import f1_score,accuracy_score,confusion_matrix
P=Path(__file__).resolve().parent
archive=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/HESD(1).zip')
with zipfile.ZipFile(archive) as z:
 raw=z.read('HESD/data/HESD.csv')
cols=['conversation_id','turn_id','split','interaction_text','security_class','enterprise_domain','user_role','asset_category','hard_negative_flag','progressive_flag']
df=pd.read_csv(io.BytesIO(raw),usecols=cols,low_memory=False).sort_values(['conversation_id','turn_id']).reset_index(drop=True)
for lag in (1,2):df[f'prev{lag}']=df.groupby('conversation_id').interaction_text.shift(lag).fillna('')
train_all=np.flatnonzero(df.split=='train');test=np.flatnonzero(df.split=='test');rng=np.random.default_rng(47)
train=rng.choice(train_all,size=min(80000,len(train_all)),replace=False)
train_text=df.iloc[train][['prev2','prev1','interaction_text']].fillna('').agg(' '.join,axis=1)
test_text=df.iloc[test][['prev2','prev1','interaction_text']].fillna('').agg(' '.join,axis=1)
vec=TfidfVectorizer(max_features=25000,ngram_range=(1,2),min_df=3,sublinear_tf=True,dtype=np.float32)
Xt=vec.fit_transform(train_text);Xe=vec.transform(test_text)
metadata=['enterprise_domain','user_role','asset_category']
enc=OneHotEncoder(handle_unknown='ignore',dtype=np.float32)
Mt=enc.fit_transform(df.iloc[train][metadata].fillna('UNKNOWN'));Me=enc.transform(df.iloc[test][metadata].fillna('UNKNOWN'))
features={'metadata_only':(Mt,Me),'history_text_only':(Xt,Xe),'history_plus_metadata':(hstack([Xt,Mt],format='csr'),hstack([Xe,Me],format='csr'))}
ytr=df.iloc[train].security_class.to_numpy();yt=df.iloc[test].security_class.to_numpy()
pr=pd.DataFrame({'conversation_id':df.iloc[test].conversation_id.to_numpy(),'truth':yt,'hard_negative_flag':df.iloc[test].hard_negative_flag.to_numpy(),'progressive_flag':df.iloc[test].progressive_flag.to_numpy()})
rows=[];classes=np.unique(yt)
for name,(a,b) in features.items():
 m=SGDClassifier(loss='log_loss',alpha=1e-5,max_iter=1000,random_state=47,class_weight='balanced')
 m.fit(a,ytr);yp=m.predict(b);pr[name]=yp
 row={'variant':name,'accuracy':accuracy_score(yt,yp),'macro_f1':f1_score(yt,yp,average='macro',zero_division=0),'reconstruction_f1':f1_score(yt=='Reconstruction',yp=='Reconstruction',zero_division=0),'hard_negative_false_alarm_rate':float(np.mean(yp[pr.hard_negative_flag==1]!='Benign')) if (pr.hard_negative_flag==1).any() else None}
 rows.append(row);print(row,flush=True)
 if name=='history_plus_metadata':
  names=np.concatenate([vec.get_feature_names_out(),enc.get_feature_names_out(metadata)]);idx=np.where(m.classes_=='Reconstruction')[0][0];top=np.argsort(m.coef_[idx])[-30:][::-1]
  pd.DataFrame({'feature':names[top],'coefficient_for_reconstruction':m.coef_[idx,top]}).to_csv(P/'reconstruction_top_features.csv',index=False)
 pd.DataFrame(confusion_matrix(yt,yp,labels=classes),index=classes,columns=classes).to_csv(P/f'confusion_{name}.csv')
pr.to_csv(P/'paired_predictions.csv',index=False);pd.DataFrame(rows).to_csv(P/'metrics.csv',index=False)
# bootstrap per conversation: common test population and resampling units
keys,inv=np.unique(pr.conversation_id,return_inverse=True);n=len(keys)
cm={}
for name in features:
 c=np.zeros((n,len(classes),len(classes)),dtype=np.int32)
 ti=np.searchsorted(classes,yt);pi=np.searchsorted(classes,pr[name].to_numpy());np.add.at(c,(inv,ti,pi),1);cm[name]=c
rng=np.random.default_rng(2026);out=[]
def macro(a):
 tp=np.diag(a);den=a.sum(0)+a.sum(1);return np.divide(2*tp,den,out=np.zeros(len(tp),dtype=float),where=den>0).mean()
for j in range(300):
 counts=rng.multinomial(n,np.full(n,1/n));v={k:macro(np.tensordot(counts,c,axes=(0,0))) for k,c in cm.items()};v['iteration']=j;v['plus_minus_text']=v['history_plus_metadata']-v['history_text_only'];v['text_minus_metadata']=v['history_text_only']-v['metadata_only'];out.append(v)
b=pd.DataFrame(out);b.to_csv(P/'cluster_bootstrap.csv',index=False)
manifest={'experiment':'03: leakage-controlled feature-group ablation (text history and observable enterprise metadata)','NOT':'Actual ASDP ATS/EKS/CIW/KEI/DRS/SSS module ablation or semantic-decoy intervention','dataset_sha256':hashlib.sha256(raw).hexdigest(),'train_turns':len(train),'test_turns':len(test),'train_conversations':df.iloc[train].conversation_id.nunique(),'test_conversations':df.iloc[test].conversation_id.nunique(),'conversation_overlap':len(set(df.iloc[train].conversation_id)&set(df.iloc[test].conversation_id)),'seed':47,'bootstrap_seed':2026,'bootstrap_replicates':300,'features':metadata+['interaction_text','two previous interaction texts'],'excluded':'security_class and all target-derived annotations, exposure variables, flags and terminal labels','python':platform.python_version(),'sklearn':sklearn.__version__,'results':rows,'cluster_bootstrap_95pct':{c:np.quantile(b[c],[.025,.975]).tolist() for c in ['plus_minus_text','text_minus_metadata']},'limitations':['Synthetic HESD','Not a causal component ablation','Metadata may be correlated with scenario-family distribution','No live enterprise gateway or semantic decoy execution']}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest['cluster_bootstrap_95pct'],indent=2))
