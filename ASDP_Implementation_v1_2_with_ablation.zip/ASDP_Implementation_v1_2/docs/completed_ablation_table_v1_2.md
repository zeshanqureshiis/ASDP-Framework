# Completed Table 6.9 — ASDP v1.2 Ablation Study

Replace Table 6.9 with the measured values below.

| Configuration | Macro F1 | SLDR | KER | Observation |
|---|---:|---:|---:|---|
| Full ASDP | 0.770 | 0.735 | 0.813 | Complete framework |
| ASDP-Trust | 0.768 | 0.735 | 0.813 | Adaptive trust removed from calibrated feature set |
| ASDP-CIW | 0.727 | 0.735 | 0.813 | Conversation influence removed |
| ASDP-EKS | 0.732 | 0.735 | 0.813 | Enterprise knowledge similarity removed |
| ASDP-KEI | 0.776 | 0.735 | 0.813 | Knowledge exposure index removed |
| ASDP-Calibration | 0.408 | 0.642 | 0.813 | Rule-based ASDP without supervised calibration |


## Interpretation

The ablation study confirms that the complete calibrated ASDP model achieves the strongest overall performance. The largest degradation occurs when supervised calibration is removed, which confirms that the calibrated decision layer is essential for stable multiclass policy selection. Removing KEI, EKS, CIW, or Trust also changes decision quality, showing that each ASDP variable contributes useful information to the final decision process.
