Experiment 01: frozen-split conversation-history control.
Includes code, predictions, metrics, bootstrap records and manifest.
Requires the original HESD dataset and dependencies to rerun.
The complete Overleaf checkpoint remains a separate ZIP.
