import numpy as np,pandas as pd,json
from pathlib import Path
p=Path('/mnt/data/asdp_stage/context_results');d=pd.read_csv(p/'context_control_predictions.csv');g=d.conversation_id.unique();inds=d.groupby('conversation_id',sort=False).indices;rng=np.random.default_rng(20261118)
from sklearn.metrics import f1_score
records=[]
for k in range(100):
 gs=rng.choice(g,len(g),replace=True);ix=np.concatenate([inds[v] for v in gs]);y=d.truth.to_numpy()[ix];a=d.ordered_history.to_numpy()[ix];b=d.current_turn.to_numpy()[ix];c=d.shuffled_history.to_numpy()[ix]
 records.append({'replicate':k,'macro_f1_ordered_minus_current':f1_score(y,a,average='macro')-f1_score(y,b,average='macro'),'reconstruction_f1_ordered_minus_current':f1_score(y=='Reconstruction',a=='Reconstruction')-f1_score(y=='Reconstruction',b=='Reconstruction'),'macro_f1_ordered_minus_shuffled':f1_score(y,a,average='macro')-f1_score(y,c,average='macro')})
r=pd.DataFrame(records);r.to_csv(p/'conversation_bootstrap.csv',index=False)
ci={k:[float(v) for v in r[k].quantile([.025,.975])] for k in r if k!='replicate'};(p/'bootstrap_intervals.json').write_text(json.dumps(ci,indent=2));print(ci)
