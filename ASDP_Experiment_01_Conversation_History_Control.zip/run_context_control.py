import pandas as pd,numpy as np,json,time,hashlib
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score,f1_score,precision_score,recall_score
p=Path('/mnt/data/asdp_stage'); out=p/'context_results';out.mkdir(exist_ok=True)
f=p/'HESD/HESD/data/HESD.csv';df=pd.read_csv(f,usecols=['conversation_id','turn_id','split','interaction_text','security_class','hard_negative_flag'],low_memory=False).sort_values(['conversation_id','turn_id']).reset_index(drop=True)
for lag in (1,2):df[f'prev{lag}']=df.groupby('conversation_id',sort=False).interaction_text.shift(lag).fillna('')
df['actual']=df.prev2+' '+df.prev1+' '+df.interaction_text
# Shuffle entire conversation histories within each frozen partition, leaving current turn unchanged.
rng=np.random.default_rng(20261118)
df['shuffled']=''
for split,idx in df.groupby('split').groups.items():
 ix=np.asarray(list(idx));perm=rng.permutation(ix)
 df.loc[ix,'shuffled']=(df.loc[perm,'prev2'].to_numpy()+' '+df.loc[perm,'prev1'].to_numpy()+' '+df.loc[ix,'interaction_text'].to_numpy())
tr=np.flatnonzero(df.split=='train');te=np.flatnonzero(df.split=='test');rng=np.random.default_rng(47);tr=rng.choice(tr,size=min(80000,len(tr)),replace=False)
# Shared vocabulary fitted only on training current-turn text; same model family and training sample.
vec=TfidfVectorizer(max_features=25000,ngram_range=(1,2),min_df=3,sublinear_tf=True,dtype=np.float32)
vec.fit(df.iloc[tr].interaction_text)
results=[];pred={}
for name,col in [('current_turn','interaction_text'),('ordered_history','actual'),('shuffled_history','shuffled')]:
 xtr=vec.transform(df.iloc[tr][col]);xte=vec.transform(df.iloc[te][col]);ytr=df.iloc[tr].security_class.to_numpy();yt=df.iloc[te].security_class.to_numpy()
 model=SGDClassifier(loss='log_loss',alpha=1e-5,max_iter=1000,random_state=47,class_weight='balanced')
 t=time.perf_counter();model.fit(xtr,ytr);fit=time.perf_counter()-t
 yp=model.predict(xte);pred[name]=yp
 rec=f1_score(yt=='Reconstruction',yp=='Reconstruction',zero_division=0)
 hn=df.iloc[te].hard_negative_flag.to_numpy()==1
 results.append({'model':name,'accuracy':accuracy_score(yt,yp),'macro_f1':f1_score(yt,yp,average='macro',zero_division=0),'reconstruction_f1':rec,'hard_negative_non_benign_rate':float(np.mean(yp[hn]!='Benign')) if hn.any() else None,'train_turns':len(tr),'test_turns':len(te),'training_seconds':fit})
 print(results[-1],flush=True)
pd.DataFrame(results).to_csv(out/'context_control_metrics.csv',index=False)
pd.DataFrame({'conversation_id':df.iloc[te].conversation_id.to_numpy(),'turn_id':df.iloc[te].turn_id.to_numpy(),'truth':df.iloc[te].security_class.to_numpy(),**pred}).to_csv(out/'context_control_predictions.csv',index=False)
manifest={'input_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'split':'frozen HESD','seed':47,'shuffle_seed':20261118,'target':'security_class','models':'three separate SGD logistic text classifiers, NOT full ASDP','vocabulary':'fit training current-turn only','excluded_target_derived_fields':True,'shuffled_control':'previous two texts independently permuted across turns within each partition; current text preserved','caveat':'This shuffled history is a negative control and is not a matched-sequence counterfactual; training and test both use shuffled histories.'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
