import pandas as pd,numpy as np,json,hashlib
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score,f1_score
P=Path(__file__).resolve().parent
src=Path('/mnt/data/ASDP_Active_Work/HESD/HESD/data/HESD.csv')
df=pd.read_csv(src,usecols=['conversation_id','turn_id','split','interaction_text','security_class'],low_memory=False).sort_values(['conversation_id','turn_id']).reset_index(drop=True)
for lag in (1,2):df[f'prev{lag}']=df.groupby('conversation_id').interaction_text.shift(lag).fillna('')
tr=np.flatnonzero(df.split=='train');te=np.flatnonzero(df.split=='test');rng=np.random.default_rng(47);tr=rng.choice(tr,size=min(80000,len(tr)),replace=False)
vec=TfidfVectorizer(max_features=25000,ngram_range=(1,2),min_df=3,sublinear_tf=True,dtype=np.float32)
vec.fit(df.iloc[tr].interaction_text)
ytr=df.iloc[tr].security_class.to_numpy();yt=df.iloc[te].security_class.to_numpy();pred={'conversation_id':df.iloc[te].conversation_id.to_numpy(),'truth':yt};rows=[]
for name,cols in [('no_history',['interaction_text']),('one_prior_turn',['prev1','interaction_text']),('two_prior_turns',['prev2','prev1','interaction_text'])]:
 texttr=df.iloc[tr][cols].fillna('').agg(' '.join,axis=1);textte=df.iloc[te][cols].fillna('').agg(' '.join,axis=1)
 model=SGDClassifier(loss='log_loss',alpha=1e-5,max_iter=1000,random_state=47,class_weight='balanced')
 model.fit(vec.transform(texttr),ytr);yp=model.predict(vec.transform(textte));pred[name]=yp
 rows.append({'variant':name,'accuracy':accuracy_score(yt,yp),'macro_f1':f1_score(yt,yp,average='macro',zero_division=0),'reconstruction_f1':f1_score(yt=='Reconstruction',yp=='Reconstruction',zero_division=0)})
 print(rows[-1],flush=True)
 if name=='two_prior_turns':
  names=vec.get_feature_names_out();ix=np.where(model.classes_=='Reconstruction')[0][0];coef=model.coef_[ix];top=np.argsort(coef)[-30:][::-1];pd.DataFrame({'term':names[top],'coefficient':coef[top]}).to_csv(P/'reconstruction_top_terms.csv',index=False)
pd.DataFrame(rows).to_csv(P/'metrics.csv',index=False);pr=pd.DataFrame(pred);pr.to_csv(P/'paired_predictions.csv',index=False)
# Cluster bootstrap difference: one/two previous turns, conversation as resampling unit
rng=np.random.default_rng(2026);groups=pr.groupby('conversation_id').indices;keys=list(groups);out=[]
from sklearn.metrics import confusion_matrix
classes=np.unique(yt); matrices={name:np.stack([confusion_matrix(yt[idx],pr[name].to_numpy()[idx],labels=classes) for idx in groups.values()]) for name in ['no_history','one_prior_turn','two_prior_turns']}
def fast_macro(cm):
 tp=np.diag(cm); denom=cm.sum(axis=0)+cm.sum(axis=1);return np.mean(np.divide(2*tp,denom,out=np.zeros_like(tp,dtype=float),where=denom>0))
for i in range(300):
 counts=rng.multinomial(len(keys),np.full(len(keys),1/len(keys)))
 d={'iteration':i}
 for name in ['no_history','one_prior_turn','two_prior_turns']:d[name]=fast_macro(np.tensordot(counts,matrices[name],axes=(0,0)))
 d['two_minus_zero']=d['two_prior_turns']-d['no_history'];d['two_minus_one']=d['two_prior_turns']-d['one_prior_turn'];out.append(d)
b=pd.DataFrame(out);b.to_csv(P/'bootstrap.csv',index=False)
manifest={'experiment':'History-length ablation; NOT an ASDP component ablation','dataset_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'training_turns':len(tr),'test_turns':len(te),'random_seed':47,'bootstrap_replicates':300,'splits':'frozen conversation-disjoint HESD','leakage_control':'Only interaction_text and previous text; no target-derived metadata','limitations':'Synthetic dataset; text-only proxy; no ATS/EKS/CIW/KEI/DRS/SSS interventions or live gateway','results':rows,'confidence_intervals':{c:np.quantile(b[c],[.025,.975]).tolist() for c in ['two_minus_zero','two_minus_one']}}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest['confidence_intervals'],indent=2))
