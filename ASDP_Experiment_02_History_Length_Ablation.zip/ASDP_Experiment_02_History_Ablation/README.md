# Experiment 02 — HESD history-length ablation

Run `python run.py` after adjusting `src` to the location of the user-provided `HESD(1).zip` extracted `HESD/data/HESD.csv`. Requirements: pandas, numpy, scikit-learn. The dataset is intentionally not duplicated in this evidence ZIP.

This evaluates 0, 1, and 2 preceding turns on frozen conversation splits, with shared training sample and vectorizer vocabulary. It is a text-only proxy, **not** an ablation of ATS/EKS/CIW/KEI/DRS/SSS, not a live decoy experiment, and not an external guardrail comparison.

Files: `metrics.csv`, `paired_predictions.csv`, `bootstrap.csv`, `reconstruction_top_terms.csv`, `manifest.json`, `run.py`. The top-term coefficients are exploratory linear-model explanations, not SHAP for the ASDP Random Forest.
